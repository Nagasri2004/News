package com.klef.fsd.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStarterProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
