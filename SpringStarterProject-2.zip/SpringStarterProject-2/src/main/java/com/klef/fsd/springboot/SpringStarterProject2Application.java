package com.klef.fsd.springboot;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStarterProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarterProject2Application.class, args);
	}

}
