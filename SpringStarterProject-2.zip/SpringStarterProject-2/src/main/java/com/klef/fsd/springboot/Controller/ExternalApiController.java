package com.klef.fsd.springboot.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klef.fsd.springboot.Service.ExternalApiService;


@CrossOrigin(origins = "http://localhost:5173/",allowCredentials = "true" )
@RestController
@RequestMapping("/api")
public class ExternalApiController {

    private final ExternalApiService apiService;

    public ExternalApiController(ExternalApiService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/external")
    public String getExternalData() {
        return apiService.getDataFromApi();
    }
}
