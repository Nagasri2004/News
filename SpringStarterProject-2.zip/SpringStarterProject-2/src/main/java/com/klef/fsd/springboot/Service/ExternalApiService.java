package com.klef.fsd.springboot.Service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.client.HttpClientErrorException;

@Service
public class ExternalApiService {
    
    private final RestTemplate restTemplate = new RestTemplate();
    private static final String API_URL = "https://eventregistry.org/api/v1/article/getArticles";
    private static final String API_KEY = "0833c086-3f2f-4dd7-aa40-974f10f4185c";  

    public String getDataFromApi() {
        try {
            String url = UriComponentsBuilder.fromHttpUrl(API_URL)
                    .queryParam("apiKey", API_KEY)
                    .queryParam("keyword", "technology")
                    .queryParam("lang", "eng")
                    .toUriString();

            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
            return response.getBody();
        } catch (HttpClientErrorException e) {
            return "Error fetching data: " + e.getMessage();
        }
    }
}
